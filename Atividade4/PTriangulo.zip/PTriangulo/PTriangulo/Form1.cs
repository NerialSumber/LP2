﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtB.Text, out ladoB) || (txtB.Text == "0") || (txtB.Text == ""))
            {
                MessageBox.Show("Lado B inválido!");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtC.Text, out ladoC)  || (txtC.Text == "0") || (txtC.Text == "")))
            {
                MessageBox.Show("Lado C inválido!");
                txtC.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(ladoB - ladoC) < ladoA) & (ladoA < ladoB + ladoC))
            {
                if ((Math.Abs(ladoA - ladoC) < ladoB) & (ladoB < ladoA + ladoC))
                {
                    if ((Math.Abs(ladoA - ladoB) < ladoC) & (ladoC < ladoA + ladoB))
                    {
                        if ((ladoA == ladoC) && (ladoB == ladoC))
                            MessageBox.Show("Seu triângulo é um triângulo Equilátero!");
                        else
                            if ((ladoA == ladoB) | (ladoA == ladoC) | (ladoB == ladoC))
                            MessageBox.Show("Seu triângulo é um triângulo Isósceles!");
                        else
                            MessageBox.Show("Seu triângulo é um triângulo Escaleno!");
                    }
                    else
                        MessageBox.Show("Lado C inválido!");
                }
                else
                    MessageBox.Show("Lado B inválido!");
            }
            else
                MessageBox.Show("Lado A inválido!");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtA.Text, out ladoA) || (txtA.Text == "0") || (txtA.Text == ""))
            {
                MessageBox.Show("Lado A inválido!");
                txtA.Focus();

            }
      
        }
    }
}
